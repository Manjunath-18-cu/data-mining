import sqlite3, numpy as np, pickle, time, pandas as pd

sigs = np.load('sigs.npy')
with open('sig_ids.pkl','rb') as f: ids = pickle.load(f)
notices = pd.read_parquet('notices.parquet')
BANDS, ROWS = 267, 4

con = sqlite3.connect('setubid.db')
cur = con.cursor()
cur.executescript('''
DROP TABLE IF EXISTS notices;
DROP TABLE IF EXISTS lsh_buckets;
DROP TABLE IF EXISTS opportunities;
DROP TABLE IF EXISTS notice_opportunity;

CREATE TABLE notices (
  notice_id TEXT PRIMARY KEY,
  portal_id TEXT NOT NULL,
  published_at TEXT NOT NULL,
  title TEXT NOT NULL,
  estimated_value INTEGER,
  closing_date TEXT
);

CREATE TABLE lsh_buckets (
  band_id INTEGER NOT NULL,
  bucket_key INTEGER NOT NULL,
  notice_id TEXT NOT NULL REFERENCES notices(notice_id)
);

CREATE TABLE opportunities (
  opportunity_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  representative_notice_id TEXT
);

CREATE TABLE notice_opportunity (
  notice_id TEXT PRIMARY KEY REFERENCES notices(notice_id),
  opportunity_id TEXT NOT NULL REFERENCES opportunities(opportunity_id),
  match_score REAL,
  matched_on TEXT,
  assigned_at TEXT
);
''')

notices_small = notices[['notice_id','portal_id','published_at','title','estimated_value','closing_date']]
notices_small.to_sql('notices', con, if_exists='append', index=False)

rows=[]
for b in range(BANDS):
    cols = sigs[:, b*ROWS:(b+1)*ROWS]
    for i,row in enumerate(cols):
        rows.append((b, int(hash(tuple(row)) % (2**63-1)), ids[i]))
cur.executemany('INSERT INTO lsh_buckets (band_id,bucket_key,notice_id) VALUES (?,?,?)', rows)
con.commit()
print("rows in lsh_buckets:", cur.execute("SELECT COUNT(*) FROM lsh_buckets").fetchone())
con.close()
